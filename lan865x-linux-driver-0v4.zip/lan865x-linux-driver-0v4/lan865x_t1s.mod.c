#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

#ifdef CONFIG_UNWINDER_ORC
#include <asm/orc_header.h>
ORC_HEADER;
#endif

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

KSYMTAB_FUNC(oa_tc6_read_registers, "_gpl", "");
KSYMTAB_FUNC(oa_tc6_read_register, "_gpl", "");
KSYMTAB_FUNC(oa_tc6_write_registers, "_gpl", "");
KSYMTAB_FUNC(oa_tc6_write_register, "_gpl", "");
KSYMTAB_FUNC(oa_tc6_start_xmit, "_gpl", "");
KSYMTAB_FUNC(oa_tc6_init, "_gpl", "");
KSYMTAB_FUNC(oa_tc6_exit, "_gpl", "");

SYMBOL_CRC(oa_tc6_read_registers, 0x5ce486bc, "_gpl");
SYMBOL_CRC(oa_tc6_read_register, 0x21c1da03, "_gpl");
SYMBOL_CRC(oa_tc6_write_registers, 0xe5137c4b, "_gpl");
SYMBOL_CRC(oa_tc6_write_register, 0xe41ce8b1, "_gpl");
SYMBOL_CRC(oa_tc6_start_xmit, 0x03d3e7fe, "_gpl");
SYMBOL_CRC(oa_tc6_init, 0x29569e52, "_gpl");
SYMBOL_CRC(oa_tc6_exit, 0x5fb71958, "_gpl");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x71fc4103, "mdiobus_alloc_size" },
	{ 0xff17c961, "alloc_etherdev_mqs" },
	{ 0xf4857a26, "devm_request_threaded_irq" },
	{ 0xfed7ef5e, "devm_kmalloc" },
	{ 0xaf35c2d3, "skb_put" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0xd8d9a649, "unregister_netdev" },
	{ 0x5fe8ff95, "skb_dequeue" },
	{ 0x92540fbf, "finish_wait" },
	{ 0x19530e1a, "phy_attached_info" },
	{ 0x4829a47e, "memcpy" },
	{ 0x64b85890, "phy_ethtool_set_link_ksettings" },
	{ 0xc3055d20, "usleep_range_state" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0xb3f7646e, "kthread_should_stop" },
	{ 0xf6ebc03b, "net_ratelimit" },
	{ 0xe2964344, "__wake_up" },
	{ 0x214001bb, "netdev_err" },
	{ 0xaa8b8983, "wake_up_process" },
	{ 0x91f3d8b2, "skb_queue_purge_reason" },
	{ 0xaea4f9cf, "dev_addr_mod" },
	{ 0x49396552, "eth_type_trans" },
	{ 0x122c3a7e, "_printk" },
	{ 0x1000e51, "schedule" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xca28284e, "phy_connect_direct" },
	{ 0x5a49888, "eth_prepare_mac_addr_change" },
	{ 0x863a57b, "skb_queue_tail" },
	{ 0x83cb18e0, "phy_ethtool_get_link_ksettings" },
	{ 0xe4b1e351, "spi_sync" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0x197f0d7b, "_dev_err" },
	{ 0x695cecb1, "kfree_skb_reason" },
	{ 0xb1b5e301, "device_get_ethdev_address" },
	{ 0x69dd3b5b, "crc32_le" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0xf06ec045, "register_netdev" },
	{ 0x6447069e, "driver_unregister" },
	{ 0xe3176db0, "free_netdev" },
	{ 0x449ad0a7, "memcmp" },
	{ 0x35bc4e62, "mdiobus_free" },
	{ 0x59c08c5b, "kthread_stop" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0x6c898682, "netif_tx_wake_queue" },
	{ 0xb2975a01, "phy_find_first" },
	{ 0x48372d5, "phy_start" },
	{ 0xdcb764ad, "memset" },
	{ 0x946b199c, "phy_print_status" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0x8ca477cf, "__pskb_pull_tail" },
	{ 0xb2084d75, "netif_rx" },
	{ 0x5828b755, "__netdev_alloc_skb" },
	{ 0x59d18360, "kthread_create_on_node" },
	{ 0x2592d9d4, "mdiobus_unregister" },
	{ 0xdd64e639, "strscpy" },
	{ 0xd9a95412, "spi_setup" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x80c234c9, "__spi_register_driver" },
	{ 0xb43f9365, "ktime_get" },
	{ 0x3c12dfe, "cancel_work_sync" },
	{ 0x12500418, "__mdiobus_register" },
	{ 0xa65c6def, "alt_cb_patch_nops" },
	{ 0x41ed3709, "get_random_bytes" },
	{ 0xa0b4d0b9, "sched_set_fifo" },
	{ 0x66dd502b, "dev_kfree_skb_any_reason" },
	{ 0x97e71417, "phy_stop" },
	{ 0xb2042fcb, "phy_disconnect" },
	{ 0x2d3385d3, "system_wq" },
	{ 0xe478ef45, "module_layout" },
};

MODULE_INFO(depends, "");

MODULE_ALIAS("of:N*T*Cmicrochip,lan8650");
MODULE_ALIAS("of:N*T*Cmicrochip,lan8650C*");

MODULE_INFO(srcversion, "20AE187C09B17AA54313F8B");
