#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

#ifdef CONFIG_UNWINDER_ORC
#include <asm/orc_header.h>
ORC_HEADER;
#endif

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x3473884, "phy_basic_t1s_p2mp_features" },
	{ 0x6a5c8d0b, "phy_write_mmd" },
	{ 0x866dbf41, "phy_drivers_unregister" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x197f0d7b, "_dev_err" },
	{ 0xc2c41a7e, "genphy_c45_plca_get_status" },
	{ 0x60a6cfd3, "phy_modify_mmd" },
	{ 0xda594c26, "mdiobus_read" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x2b2bc5d9, "phy_drivers_register" },
	{ 0xb5b5e5ca, "genphy_c45_plca_set_cfg" },
	{ 0x23ecbf8c, "phy_read_mmd" },
	{ 0xbf08f3a2, "genphy_c45_plca_get_cfg" },
	{ 0xe478ef45, "module_layout" },
};

MODULE_INFO(depends, "");

MODULE_ALIAS("mdio:00000000000001111100000101100010");
MODULE_ALIAS("mdio:00000000000001111100000101100100");
MODULE_ALIAS("mdio:00000000000001111100000101100101");
MODULE_ALIAS("mdio:00000000000001111100000110110011");

MODULE_INFO(srcversion, "9BFC36762D3DA8A122B2FF2");
